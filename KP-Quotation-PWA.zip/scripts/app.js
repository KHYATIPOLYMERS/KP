
const GAS_URL = 'https://script.google.com/macros/s/AKfycbxxxxx/exec'; // Replace with your real URL

function loadQuotations() {
  fetch(`${GAS_URL}?action=getQuotationList`)
    .then(res => res.json())
    .then(data => {
      const list = document.getElementById("quotationList");
      list.innerHTML = "";
      data.slice(0, 15).forEach(q => {
        const li = document.createElement("li");
        li.textContent = q;
        li.onclick = () => openQuotation(q);
        list.appendChild(li);
      });
    });
}

function openQuotation(q) {
  alert("Opening: " + q);
}

function createNewQuotation() {
  fetch(`${GAS_URL}?action=createNewQuotation`)
    .then(res => res.text())
    .then(newId => {
      alert("Created New: " + newId);
      loadQuotations();
    });
}

window.onload = loadQuotations;
